#mutiplication tool
print("insert your first number:")
Number1 = int(input())
print("Using " + str(Number1) + " to add:")
Number2 = int(input())
NumberF = Number1 * Number2
print(str(Number1) + " + " + str(Number2) + " = " + str(NumberF))