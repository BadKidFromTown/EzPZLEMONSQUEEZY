Edge = 50
Edge2 = 50
Square = Edge * Edge2
print("Square is " + str(Square))
"Casting =============>"
str(Square)