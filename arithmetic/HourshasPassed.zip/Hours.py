Clock = 11.59

Minutes_Since_Midnight = 11* 60 + 59

print("The time has passed in minute since midnight is " + str(Minutes_Since_Midnight) + " Minutes")