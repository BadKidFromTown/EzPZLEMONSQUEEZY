#Physics Formula: Gravity.
#How Much do you weight?
#We will find out.
#instructions: Type in your mass and see how it goes.

Mass = 108
Mass_Unit = "kg"
Gravity_Index_Earth = 9.81
Gravity_Unit = "m/s^2"
Weight = Mass * Gravity_Index_Earth
Weight_Unit = "Neutons"

print("You weight " + str(Weight) + Weight_Unit)