#Backwards is always right. 
Array1 = []
def Function(Array):
    i = len(Array)
    while i > 0:
        i = i - 1
        Array1.append(Array[i])
    print(Array1)
Function([1,2,3,4,5,6,7])
