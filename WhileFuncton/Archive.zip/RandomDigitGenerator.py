import random



def RandomDigitGenerator(Number):
    Array = []
    for x in range(10):
        Array.append(random.randint(0,Number))
    print(Array)



RandomDigitGenerator(5)