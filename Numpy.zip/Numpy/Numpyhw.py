import numpy as np
import random
Random_Series_1 = [random.randint(0,100), random.randint(0, 100), random.randint(0,100), random.randint(0, 100)]
Random_Series_2 = [random.randint(0,100), random.randint(0, 100), random.randint(0,100), random.randint(0, 100)]
Random_Series_3 = [random.randint(0,100), random.randint(0, 100), random.randint(0,100), random.randint(0, 100)]
Random_Series_4 = [random.randint(0,100), random.randint(0, 100), random.randint(0,100), random.randint(0, 100)]
a = np.matrix([Random_Series_1, Random_Series_2, Random_Series_3, Random_Series_4])
print(a)
    