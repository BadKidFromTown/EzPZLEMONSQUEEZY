import random
def Reverse_Method(Range):
    The_String = []
    y = 0
    while y < Range:
        The_String.append(random.randint(1,100))
        y = y + 1
    print(len(The_String))
    print(The_String)
    Reverse_Length = len(The_String) / 2
    print(Reverse_Length)
    x = 0
    while x < Reverse_Length:
        The_String[x], The_String[len(The_String)-1-x] = The_String[len(The_String)-1-x], The_String[x]
        x = x + 1
    print(The_String)
Reverse_Method(20)

